This is a library for Intel Edison BT SPP driver

This library has provided BT connectivity from on-board BT chip of Intel Edison. We get the BT SPP input via a named pipe in Linux. You'll need additional files to activate BT SPP and named pipe under Linux.

Written by Franky Hsieh for Intel Corp. LLC. 
MIT license, check license.txt for more information
All text above must be included in any redistribution
